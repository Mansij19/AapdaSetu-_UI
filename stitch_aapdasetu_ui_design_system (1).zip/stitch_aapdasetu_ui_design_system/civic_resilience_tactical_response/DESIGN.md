---
name: Civic Resilience & Tactical Response
colors:
  surface: '#f9f9ff'
  surface-dim: '#d1daf4'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8ff'
  surface-container-highest: '#d9e2fc'
  on-surface: '#121b2e'
  on-surface-variant: '#43474e'
  inverse-surface: '#273044'
  inverse-on-surface: '#edf0ff'
  outline: '#73777f'
  outline-variant: '#c3c6d0'
  surface-tint: '#40608b'
  primary: '#002549'
  on-primary: '#ffffff'
  primary-container: '#173b64'
  on-primary-container: '#86a6d5'
  inverse-primary: '#a8c8f9'
  secondary: '#ab3422'
  on-secondary: '#ffffff'
  secondary-container: '#fc6f57'
  on-secondary-container: '#6b0700'
  tertiary: '#332100'
  on-tertiary: '#ffffff'
  tertiary-container: '#4f3500'
  on-tertiary-container: '#d19a32'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#a8c8f9'
  on-primary-fixed: '#001c39'
  on-primary-fixed-variant: '#264872'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a6'
  on-secondary-fixed: '#400200'
  on-secondary-fixed-variant: '#8a1c0d'
  tertiary-fixed: '#ffdeac'
  tertiary-fixed-dim: '#f8bc52'
  on-tertiary-fixed: '#281900'
  on-tertiary-fixed-variant: '#5f4100'
  background: '#f9f9ff'
  on-background: '#121b2e'
  surface-variant: '#d9e2fc'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: 4rem
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Manrope
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Manrope
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Manrope
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  headline-sm:
    fontFamily: Manrope
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
  metric-display:
    fontFamily: Manrope
    fontSize: 2rem
    fontWeight: '800'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

### Personality & Mission
The design system projects unwavering civic authority, institutional trust, calm tactical precision, and human-centric urgency. Built to govern real-time emergency workflows—from localized incidents around Indore (e.g., Rajwada flash-logging, Vijay Nagar traffic diversions, Palasia medical corridors) to nationwide disaster response—the visual system eliminates cognitive overload. It guarantees immediate visual triage under intense emotional and environmental stress.

### Design Movement & Aesthetic Direction
The visual language operates at the intersection of **High-Reliability Gov-Tech SaaS** and **Tactical Modernism**:
- **Structured Precision:** Crisp, deliberate layouts with crisp division lines, high data density, and clear typographic hierarchy.
- **Multimodal Redundancy:** Life-critical states never depend on color alone; every alert tier reinforces status via distinct geometric iconography, structured labeling, and high-contrast color indicators.
- **Dual Portal Cohesion:** 
  - *Citizen Portal:* High-touch, accessible, mobile-first interface optimized for one-tap SOS actions, rapid offline-first incident reporting, and unambiguous visual safety trackers.
  - *Authority & Dispatch Console:* Information-dense command cockpit prioritizing GIS overlays, real-time dispatch telematics, tabular triage metrics, and rapid incident escalation workflows.

## Colors

The color architecture enforces operational discipline across light and high-glare field environments. Critical states map directly to emergency severity levels:

### Color Roles & Semantic Application
- **Primary Navy (`#173B64`):** Anchors institutional authority, structural chrome, persistent navigation, primary controls, and dominant tactical headings.
- **Emergency Red (`#E15B45`):** Reserved exclusively for active life-safety threats, SOS broadcasts, critical evacuation corridors, and destructive system actions. Never diluted for decorative purposes.
- **Warning Amber (`#D69E36`):** Communicates severe weather advisories, surging river levels (e.g., Kahn & Saraswati rivers), structural risks, and unverified citizen incident inputs awaiting administrative triage.
- **Safe Green (`#24856B`):** Identifies resolved distress tickets, verified relief shelters (e.g., Nehru Stadium Relief Depot), green-lighted supply routes, and stable civic zones.
- **Surface Foundations:**
  - Canvas Base: `#F8FAFC` (Calm, neutral backdrop preventing screen fatigue in command centres).
  - Surface Panel / Card: `#FFFFFF` with structural hairline stroke `#E2E8F0`.
- **Text & Hierarchy:**
  - Primary Text: `#172033` (Exceeds WCAG AAA contrast ratio on white surfaces).
  - Secondary Text: `#475569` (For descriptive guidance, meta captions, and secondary telemetry).
  - Muted Text: `#64748B` (Timestamps, geospatial coordinates, table column headers).

## Typography

The typographic hierarchy uses **Manrope** for authoritative structural framing and **Inter** for dense transactional interfaces:
- **Manrope:** Provides structural gravity for high-level incident bulletins, broadcast alert headers, and telemetry KPI readouts. Its geometric form factor ensures fast comprehension across digital billboards and mobile alert banners.
- **Inter:** Ensures optical clarity across data tables, dispatch logs, status trackers, and field-worker inputs. Tabular figures (`tnum`) must be enforced for all numeric metric indicators, GPS coordinates (e.g., `22.7196° N, 75.8577° E`), and time-elapsed stamps to prevent visual jitter during live updates.
- **Bilingual & Localization Considerations:** All typographic levels accommodate Devanagari script pairings alongside English without vertical clipping by preserving a minimum 1.4× line-height ratio across bilingual microcopy.

## Layout & Spacing

The spatial architecture handles dual-operating realities: compact mobile field units and expansive command center displays.

### Layout Philosophy
- **Responsive 12-Column Fluid Grid:** Standard desktop environments leverage a fluid 12-column grid system anchored by `gutter` (1.5rem) and outer `margin` (2rem). Elements scale along 3, 4, 6, 8, or 12 column partitions.
- **Mobile First Incident Flow:** Handheld citizen interfaces collapse to a 4-column layout with strict 1rem (`space-md`) safety paddings, ensuring thumb-accessible touch targets (minimum 48×48px) for emergency reporting.
- **Command Density Layouts:** Command consoles (1440px+) utilize split-pane viewports: fixed 380px contextual left triage panels, fluid central GIS viewports, and collapsible 320px telemetry right drawers.

## Elevation & Depth

Visual hierarchy uses crisp structural containment, tonal surface stacking, and purposeful elevation to signify situational urgency rather than decorative flair.

### Stacking & Shadow Architecture
- **Base Level (Canvas):** Flat `#F8FAFC` slate background without elevation.
- **Level 1 (Card & Module Panels):** Grounded `#FFFFFF` surface framed by a 1px solid border `#E2E8F0` and subtle, ambient contact shadow:
  `box-shadow: 0 1px 3px 0 rgba(23, 32, 51, 0.05), 0 1px 2px -1px rgba(23, 32, 51, 0.03);`
- **Level 2 (Hover States, Flyouts, Table Row Selections):** Moderate elevation signaling interaction ready:
  `box-shadow: 0 4px 6px -1px rgba(23, 32, 51, 0.08), 0 2px 4px -2px rgba(23, 32, 51, 0.04);`
- **Level 3 (Modals, Dispatch Overlays, Triage Drawers):** High separation for mission-critical overrides:
  `box-shadow: 0 20px 25px -5px rgba(23, 32, 51, 0.12), 0 8px 10px -6px rgba(23, 32, 51, 0.06);`
- **Emergency Beacon Halo (SOS & Critical Alerts):** Dynamic, pulsating glow reserved solely for Level-1 Critical hazards:
  `box-shadow: 0 0 0 4px rgba(225, 91, 69, 0.25);`

## Shapes

The design system enforces a **Soft (`1`)** roundedness standard. This balanced radius (0.25rem / 4px base, scaling to 0.5rem / 8px for standard cards and inputs, and 0.75rem / 12px for modal surfaces) delivers a disciplined, governmental aesthetic.

- **Buttons & Input Fields:** 0.5rem (`rounded-lg`) corner radii convey modern accessibility while preserving crisp geometric alignment.
- **Status Pills & Metric Badges:** Strict capsule pill styling (`rounded-full` / 9999px) for fast visual recognition against squarer card structures.
- **Map Overlays & Critical Alert Containers:** 0.5rem corner radii with reinforced 1px containment borders to maintain clean alignment against geospatial layers.

## Components

### 1. Buttons
- **Primary Civic Action:** Background `#173B64`, text `#FFFFFF`, 0.5rem radius, padding 0.625rem 1.25rem, Inter `label-lg`. Focus state: 2px offset with 2px solid `#173B64`.
- **Emergency SOS (Citizen Primary):** Prominent height (56px minimum), background `#E15B45`, text `#FFFFFF`, bold Manrope `headline-sm`, high-contrast iconography. Includes dual Hindi/English labels ("SEND SOS / आपातकालीन सहायता").
- **Secondary / Ghost:** Transparent background, 1px solid border `#CBD5E1`, text `#172033`, hover background `#F1F5F9`.

### 2. Status Chips & Badges
- Built on a strict three-part formula: `[Geometric SVG Icon] + [Text Status] + [High-Contrast Tonal Background]`.
- **Critical / Danger:** Background `#FEE2E2`, border `#FECACA`, text `#991B1B`, icon: Octagon Exclamation.
- **Warning / Review:** Background `#FEF3C7`, border `#FDE68A`, text `#92400E`, icon: Triangle Caution.
- **Safe / Resolved:** Background `#DCFCE7`, border `#BBF7D0`, text `#166534`, icon: Shield Check.
- **Civic Notice:** Background `#E0E7FF`, border `#C7D2FE`, text `#3730A3`, icon: Info Circle.

### 3. Cards & Incident Panels
- Background `#FFFFFF`, 1px solid `#E2E8F0`, 0.5rem corner radius, 1.25rem internal padding.
- **Urgent Incident Card:** Left-anchored 4px vertical accent stripe indicating severity: `#E15B45` for active distress (e.g., Bhanwarkua Waterlogging Level 3), `#D69E36` for monitoring, `#24856B` for all-clear zones. Includes tabular metadata header: Incident ID, Timestamp, Sector, and Assigned Unit.

### 4. Input Fields & Form Controls
- Text inputs: 44px field height, background `#FFFFFF`, border 1px solid `#CBD5E1`, 0.5rem radius, Inter `body-md` text `#172033`. Active focus: border `#173B64` with 3px subtle halo `rgba(23, 59, 100, 0.15)`.
- Emergency Form Modals feature high-visibility inline validation with clear error messages and persistent dismiss/submit actions.

### 5. Checkboxes & Radio Buttons
- 20×20px box dimensions, 4px border radius for checkboxes, full circle for radios.
- Unchecked: 1.5px border `#94A3B8`, background `#FFFFFF`.
- Checked: Background `#173B64` with clean white checkmark / center dot.

### 6. Command Center Data Tables (Government Portal)
- Row height: 48px dense, 60px relaxed.
- Headers: Background `#F1F5F9`, Inter `label-md`, text `#475569`, uppercase with 0.05em tracking.
- Row striping: Alternate `#FFFFFF` and `#F8FAFC`. Active triage selection: left 3px `#173B64` border with `#EFF6FF` tint.
- Numeric metrics (Casualties, Responders, Fleet Units) right-aligned with tabular figures enabled.

### 7. Bilingual Citizen SOS Trigger Banner
- Fixed bottom sheet on citizen mobile viewports.
- Distinct split layout: Large `#E15B45` SOS trigger on the left; one-tap direct line to Indore District Control Room (1077 / 112) on the right. High-contrast typography readable under direct sunlight.